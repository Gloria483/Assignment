﻿Public Class customers
    Dim id As Integer = Nothing
    Private Sub customers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
        View()
    End Sub
    Private Sub view()
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "Select * from Customers"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
        End Try
    End Sub
    Private Sub DeleteSite(ByRef customer_ID As String)

        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter

            sql = "DELETE * from Customers WHERE customer_ID=" & customer_ID & ""
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox("customer is successfully delted!")

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles DELETE.Click
        If (id <> Nothing) Then
            DeleteSite(id)
            View()

        Else
            MsgBox("Please select any of the sites from the table below!")
        End If

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            id1.Text = row.Cells(0).Value.ToString
            order.Text = row.Cells(4).Value.ToString
            name1.Text = row.Cells(1).Value.ToString
            location1.Text = row.Cells(2).Value.ToString
            tel1.Text = row.Cells(3).Value.ToString
            id = CInt(row.Cells(0).Value.ToString)


        End If
    End Sub
    Sub Updatecustomer(ByRef name1 As String, ByRef location1 As String, ByRef order As String, ByRef tel1 As String, ByRef id1 As Integer)
        Dim sql As String
        Try
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "UPDATE Customers SET customer_name='" & name1 & "',customer_location='" & location1 & "',customer_tel='" & tel1 & "' ,order='" & order & "' WHERE customer_ID=" & id1 & ""
            'sql = "UPDATE Customers SET customer_name='" & name1 & "',customer_location='" & location1 & "', customer_tel='" & tel1 & "', order ='" & order & "' WHERE customer_ID=" & 4
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox(" customer with this id number" & id1 & " is updated!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub UPDATE_Click(sender As Object, e As EventArgs) Handles UPDATE.Click

        Dim name, location, Telephone, order1, custID As String
        custID = id1.Text
        name = name1.Text
        location = location1.Text
        Telephone = tel1.Text
        order1 = order.Text
        ' MsgBox(name)
        If (id <> Nothing) Then
            'MsgBox(id)
            Updatecustomer(name, location, Telephone, order1, id)
            view()

        Else
            MsgBox("Please select any of the customer from the table below!")
        End If

    End Sub
End Class
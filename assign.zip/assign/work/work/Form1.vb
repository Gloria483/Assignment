﻿Public Class Form1
    Private Sub CustomersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomersToolStripMenuItem.Click
        customers.Show()

    End Sub

    Private Sub OrdersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrdersToolStripMenuItem.Click
        orders.Show()


    End Sub

    Private Sub DeliverersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeliverersToolStripMenuItem.Click
        deliverers.Show()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()

    End Sub
End Class
